<form id="myform">
  <input type="button" value="X" name="B1" onClick="parent.emailwindow.hide()" /></p>
</form>
